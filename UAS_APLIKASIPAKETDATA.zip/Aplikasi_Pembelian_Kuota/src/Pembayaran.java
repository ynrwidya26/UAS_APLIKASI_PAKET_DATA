import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pembayaran extends JFrame {
    JRadioButton rdOvo, rdGopay, rdMbanking;
    ButtonGroup bgJenisPembayaran;
    JButton btnBayar, btnBatal;
    public Pembayaran(){
        setTitle("Pembayaran");
        setSize(450, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setLayout(new FlowLayout(FlowLayout.CENTER));

        rdOvo = new JRadioButton("Ovo");
        rdGopay = new JRadioButton("Gopay");
        rdMbanking = new JRadioButton("M-Banking");

        bgJenisPembayaran = new ButtonGroup();
        bgJenisPembayaran.add(rdOvo);
        bgJenisPembayaran.add(rdGopay);
        bgJenisPembayaran.add(rdMbanking);

        btnBayar = new JButton("Purchase");
        btnBatal = new JButton("Cancel");

        add(new JLabel("Pembayaran melalui: "));
        add(rdOvo);
        add(rdGopay);
        add(rdMbanking);

        add(btnBayar);
        add(btnBatal);

        btnBatal.addActionListener(new ButtonBatalListener());
        btnBayar.addActionListener(new ButtonBayarLstener());

        setVisible(true);
    }

    class ButtonBatalListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            new Pemilihan();
        }
    }

    class ButtonBayarLstener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null, "pembelian kuota berhasil");
        }
    }
}
