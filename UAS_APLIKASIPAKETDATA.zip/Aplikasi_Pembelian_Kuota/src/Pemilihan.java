import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pemilihan extends JFrame {

    public Pemilihan() {
        setTitle("Pemilihan Paket");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(new DataPanel());
        add(new CbPanel());
        add(new ButtonPanel());


        setVisible(true);
    }
}
class DataPanel extends JPanel {
    String columnNames[] = {"Pembelian ID", "Paket", "Harga"};
    Object[][] data = {
            {"U001", "Paket Internet Harian", 7000},
            {"U002", "Paket Internet Mingguan", 25000},
            {"U003", "Paket Internet Bulanan", 60000},
            {"U004", "Paket Malam", 45000},
            {"U005", "Paket Belajar", 35000}
    };
    public DataPanel(){
        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        table.setFillsViewportHeight(true);
        table.setEnabled(false);

        setLayout(new GridLayout(1, 1));
        setBorder(new EmptyBorder(10, 10, 0, 10));

        add(scrollPane);
    }
}

class CbPanel extends JPanel {
    JComboBox<String> cmbPaket = new JComboBox<>(new String[] {
            "I001",
            "I002",
            "I003",
            "I004",
            "I005"
    });
    public CbPanel() {
        setLayout(new GridLayout(5, 2));

        add(new JLabel("Paket"));
        add(cmbPaket);

        //border
        Border etchedBorder = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);

        TitledBorder titledBorder = BorderFactory.createTitledBorder(etchedBorder, "Pilih Paket yang diinginkan");
        titledBorder.setTitleFont(titledBorder.getTitleFont().deriveFont(Font.BOLD));

        setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 10, 10), titledBorder));

    }
}

class ButtonPanel extends JPanel {
    JButton btnYes = new JButton("Yes");

    public ButtonPanel() {
        setLayout(new GridLayout(1, 4));
        add(btnYes);
        btnYes.addActionListener(new ButtonYesListener());
    }

    class ButtonYesListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {new Pembayaran();
        }

    }
}
