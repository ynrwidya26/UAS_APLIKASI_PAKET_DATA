import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Login extends JFrame {
    JTextField txtNama;
    JPasswordField pass;
    JButton btnLogin;

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    public Login(){
        setTitle("Aplikasi Pembelian Kuota");
        setSize(275, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        txtNama = new JTextField(20);
        pass = new JPasswordField(10);
        btnLogin = new JButton("Login");

        add(new JLabel("Username"));
        add(txtNama);
        add(new JLabel("Password"));
        add(pass);
        add(btnLogin);


        btnLogin.addActionListener(new ButtonLoginListener());

        setVisible(true);

    }
    class ButtonLoginListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {

        try {
            String query = "SELECT * FROM login WHERE username=? and userpass=?";
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kuota", "root", "");
            pst = con.prepareStatement(query);
            pst.setString(1, txtNama.getText());
            pst.setString(2, String.valueOf(pass.getPassword()));
            rs = pst.executeQuery();
            if (rs.next()){
                JOptionPane.showMessageDialog(null, "username and password matched");
            }
        }
            catch (Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());

        }
         new Pemilihan();
        }
    }

}
